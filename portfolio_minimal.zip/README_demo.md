# Demo: arranque rápido

Este repositorio incluye scripts auxiliares para arrancar y parar rápidamente una copia demo del proyecto.

Requisitos
- Windows PowerShell (pwsh)
- Python + venv (el script crea `.venv` si falta)

Comandos principales

- Arrancar el servidor de desarrollo (mata procesos que ocupen el puerto si se usa `-Force`):

```powershell
.\scripts\start_demo.ps1 -Port 8000 -Force
```

- Parar el servidor (lee `.server_pid` o, con `-Force`, mata procesos que estén escuchando en el puerto):

```powershell
.\scripts\stop_demo.ps1 -Port 8000 -Force
```

¿Qué hace `start_demo.ps1`?
- Asegura que exista `.venv` y usa ` .venv\Scripts\python.exe`.
- Actualiza pip e instala `requirements.txt` si está presente.
- Ejecuta `migrate --noinput`.
- Ejecuta `scripts/create_demo.py` si existe para poblar datos de demo.
- Inicia `manage.py runserver 127.0.0.1:<Port>` usando el Python del venv, redirigiendo stdout/stderr a `server_stdout.log` / `server_err.log`.
- Escribe el PID del proceso en `.server_pid`.

Archivos relevantes
- `.server_pid` — PID del proceso Python que corre el servidor (si arrancó desde `start_demo.ps1`).
- `server_stdout.log`, `server_err.log` — logs del servidor.
- `templates/registration/login.html` — shim que reutiliza `templates/login.html` para la vista de login.

Credenciales demo
- admin: `demo_admin` / `demo1234` (si `scripts/create_demo.py` crea el superusuario, que es el comportamiento por defecto)

Notas y troubleshooting
- Si el script detecta que el puerto ya está en uso, por defecto no mata procesos para evitar pérdida de datos; usa `-Force` para forzar cierre.
- Revisa `server_err.log` si ves errores 500 en el sitio.
- Si quieres usar la plantilla `registration/login.html` exacta del proyecto original, cópiala a `templates/registration/login.html` (actualmente hay un shim que incluye `templates/login.html`).

Contacto
- Si quieres que adapte los scripts (p. ej. `-NoBrowser`, arranque en 127.0.0.1 sólo, o logging adicional), dime qué prefieres y lo implemento.

Portafolio / preparación para mostrar
- Si vas a presentar este proyecto en un portafolio, hay un documento principal con recomendaciones y el estado final en `README_PORTFOLIO.md`.
# README - Demo (Familia Calendario)

## Objetivo

Este README explica cómo ejecutar la versión de demo/portafolio del proyecto "familia_calendario_public".
Es una copia ligera del proyecto original (basado en `C:\Users\j\familia_calendario`) preparada para mostrar en CV o entrevistas.

## Resumen de la demo

- Aplicación Django con vistas públicas (inicio, tareas, calendario, miembros, demo).
- Plantillas mínimas añadidas para que la demo funcione sin errores (por ejemplo `base.html`, `tareas_lista.html`, `calendario.html`, `admin_miembros.html`).
- `scripts/start_demo.ps1` — prepara venv, aplica migraciones, crea datos demo y abre el servidor en una nueva ventana; guarda PID en `.server_pid`.
- `scripts/stop_demo.ps1` — detiene el proceso registrado en `.server_pid`.
- `scripts/create_demo.py` — crea superusuario demo y datos de ejemplo.

## Requisitos (local)

- Windows PowerShell (pwsh.exe recomendado)
- Python 3.11+ (probado con 3.13)
- Git (opcional)

## Archivos importantes

- `manage.py` — entrada Django (ya configurada).
- `hogar/settings.py` — settings del proyecto (DEBUG=True por defecto en demo).
- `templates/` — plantillas usadas por la demo (se añadieron las mínimas necesarias).
- `scripts/start_demo.ps1` — preparar y arrancar demo en otra ventana.
- `scripts/stop_demo.ps1` — detener demo.
- `scripts/create_demo.py` — crear datos demo.

## Credenciales demo

- Usuario: `demo_admin`
- Contraseña: `demo1234`

> Nota: no uses estas credenciales en producción; son sólo para la demo local.

## Cómo ejecutar (PowerShell)

Abre PowerShell en la raíz del repositorio (`C:\Users\j\familia_calendario_public`) y ejecuta:

1) Iniciar demo (abre una nueva ventana y espera a que el servidor esté listo):

```powershell
.\scripts\start_demo.ps1
```

El script hará:
- crear/usar `.venv` (si no existe), instalar dependencias (si `requirements.txt` está presente), ejecutar `makemigrations/migrate` y `scripts/create_demo.py`.
- abrir una nueva ventana PowerShell y ejecutar `python manage.py runserver 127.0.0.1:8000` usando el Python de la venv.
- esperará hasta que el puerto esté listo y guardará el PID en `.server_pid`.
- intentará abrir el navegador en `http://127.0.0.1:8000/`.

2) Verificar desde la ventana actual:

```powershell
# ver PID guardado
Get-Content .server_pid

# comprobar listener en el puerto 8000
netstat -a -n -o | Select-String ":8000"

# comprobación HTTP rápida
Invoke-WebRequest http://127.0.0.1:8000 -UseBasicParsing
Invoke-WebRequest http://127.0.0.1:8000/tareas/ -UseBasicParsing
Invoke-WebRequest http://127.0.0.1:8000/calendario/ -UseBasicParsing
Invoke-WebRequest http://127.0.0.1:8000/demo/ -UseBasicParsing
```

3) Parar el demo:

```powershell
.\scripts\stop_demo.ps1
```

Si la ventana donde se lanzó el servidor muestra un error, revisa esa ventana: `start_demo.ps1` abre la ventana y el output del servidor aparecerá allí.

## Notas técnicas / seguridad

- `DEBUG` está activado para facilitar debug en local (no usar en producción).
- La API (`/api/`) está protegida por defecto (DRF `IsAuthenticated`). Si quieres mostrar la API pública en el demo, edita `hogar/settings.py` y ajusta `REST_FRAMEWORK['DEFAULT_PERMISSION_CLASSES']` a `['rest_framework.permissions.AllowAny']` (solo para demo).
- El script `scripts/create_demo.py` crea el superusuario `demo_admin` con contraseña `demo1234`.

## Plantillas y cambios realizados

Para que la demo funcione sin depender de plantillas privadas del repositorio original, se añadieron plantillas mínimas:
- `templates/base.html` (layout mínimo con nav y bloques `title`/`content`).
- `templates/tareas_lista.html` (lista de tareas con paginación).
- `templates/calendario.html` (vista calendario demo).
- `templates/admin_miembros.html` (vista miembros/avisos demo).
- `templates/registration/login.html` (login mínimo).

## Comprobaciones rápidas

Puedes correr estos pasos para verificar que el demo está listo:

```powershell
.\scripts\start_demo.ps1
# una vez listo
Invoke-WebRequest http://127.0.0.1:8000 -UseBasicParsing
Invoke-WebRequest http://127.0.0.1:8000/tareas/ -UseBasicParsing
Invoke-WebRequest http://127.0.0.1:8000/calendario/ -UseBasicParsing
```

## Siguientes pasos recomendados (para CV / portafolio)

- Añadir `demo_screenshots/` con 2-3 capturas (home, calendario, tareas).
- Documentar arquitectura breve: modelos clave y endpoints API (README técnico adicional).
- Si quieres exponer la API en el demo, puedo añadir un endpoint público limitado o tokens demo.

Si quieres que haga alguno de estos pasos ahora (añadir screenshots, publicar API demo, o crear README técnico con endpoints y ejemplos curl/python), dime cuál y lo hago.

